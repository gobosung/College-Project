#include "Star.h"

using namespace std;

int main()
{
	srand(time(NULL));
	Star a(20, 20);
	a.setSpeed(100);
	//���� �߰�
    a.setLevel(50);
	int i;
	int j;
	int x = 0;
	int y = 0;
	gotoxy(x, y);
	int width = 20;
	int height = 20;

	cout << "";

	for (i = 0; i < width * 2; i++)
	{
		cout << "";
	}
	cout << "";

	for (i = 0; i < height; i++)
	{
		y++;
		gotoxy(x, y);
		cout << "";

		for (j = 0; j < width * 2; j++)
		{
			cout << "  ";
		}

		x += width * 2 + 1;
		gotoxy(x, y);
		cout << "";
		x = 0;
	}
	gotoxy(x, y);

	cout << "";
	for (i = 0; i < width * 2; i++)
	{
		cout << "";
	}
	cout << "";
	while (1)
	{
		a.StarManager();
	}

	//fork() �Լ��� ���ؼ� �˾ƺ���
	//���� ������ ������ ���
}